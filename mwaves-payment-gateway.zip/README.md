# Mwaves Payment Gateway

This is the initial setup for the Mwaves Payment Gateway project.

## Installation

1. Clone the repository.
2. Run `npm install` to install dependencies.
3. Run `npm run dev` to start the server in development mode.

## Technologies Used
- Express.js
- Node.js
- dotenv
- body-parser
